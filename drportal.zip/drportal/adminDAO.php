<?php

class AdminDAO {    
    public function __construct(){
		
    }
	
	public function addAdmin($con) {
		$name = 'Super User';
		$lastname = 'Admin';
		$cellNumber = '012345678';
		$email = 'admin@system.co.za';
		$role = 'admin';
		$password = password_hash("abcde", PASSWORD_DEFAULT);
		$checkEmail = mysqli_fetch_array(mysqli_query($con,"SELECT * FROM tblLogin WHERE username = '$email'"));
		if(isset($checkEmail)) {
			return "User with the same email address already exist";
		} else {
			$sql = "INSERT INTO tblLogin(username,password,role) VALUES('$email','$password','$role')";
			$sqlUser = "INSERT INTO tbluser(name,lastname,cellNumber,email) VALUES('$name','$lastname','$cellNumber', '$email')";
			if(mysqli_query($con,$sql) AND mysqli_query($con,$sqlUser)) {	
				return "Successfully registered";
			} else  {
				return "Unsuccessfully registered";
			}
		}
	}
		
    public function addUser($con,$name, $lastname, $cellNumber, $email, $password, $role) {
		$password = password_hash($password, PASSWORD_DEFAULT);
		$checkEmail = mysqli_fetch_array(mysqli_query($con,"SELECT * FROM tblLogin WHERE username = '$email'"));
		if(isset($checkEmail)) {
			return "User with the same email address already exist";
		} else {
			$sql = "INSERT INTO tblLogin(username,password,role) VALUES('$email','$password','$role')";
			$sqlUser = "INSERT INTO tbluser(name,lastname,cellNumber,email) VALUES('$name','$lastname','$cellNumber', '$email')";
			if(mysqli_query($con,$sql) AND mysqli_query($con,$sqlUser)) {	
				return "Successfully registered";
			} else  {
				return "Unsuccessfully registered";
			}
		}
    }
	
			
    public function addDoctor($con,$name, $lastname, $cellNumber, $email, $password, $role, $place, $practiceNumber) {
		$cehckPracticeNumber = mysqli_fetch_array(mysqli_query($con,"SELECT * FROM tbldoctors WHERE practiceNumber = '$practiceNumber'"));
		if(isset($cehckPracticeNumber)) {
			return "Doctor with the same practice number already exist";
		} else {
			if ($this->addUser($con,$name, $lastname, $cellNumber, $email, $password, $role) == "Successfully registered") {
				$result = mysqli_query($con,"SELECT id FROM tbluser where email = '$email'");
				if($row = mysqli_fetch_array($result)){
					$userId = $row["id"];
					$sql = "INSERT INTO tbldoctors(userId,practiceNumber,place) VALUES('$userId','$practiceNumber','$place')";
					if(mysqli_query($con,$sql)) {
						return "Successfully registered";
					} else {
						return "Unsuccessfully registered";
					}
				} else {
					return "Unsuccessfully registered";
				}
			} else {
				return "Unsuccessfully registered";
			}
		}

    }
	
	public function deactivateUser($con, $email){
		$status = "Deactivated";
		$sql = "UPDATE tbllogin SET status ='$status' WHERE username ='$email'";
		if ($con->query($sql) == TRUE){
			return "User successfully deactivated";
		} else {
			return "User unsuccessfully deactivated";
		}
    }
	
	public function activateUser($con, $email){
		$status = "Active";
		$sql = "UPDATE tbllogin SET status ='$status' WHERE username ='$email'";
		if ($con->query($sql) == TRUE){
			return "User successfully Activated";
		} else {
			return "User unsuccessfully Activated";
		}
    }
	
	public function treatPatient($con, $id, $comment){
		$status = "Done";
		$sql = "UPDATE tblbooking SET status ='$status', comment ='$comment' WHERE id ='$id'";
		if ($con->query($sql) == TRUE){
			return "Patient treated successfully";
		} else {
			return "Something went wrong";
		}
    }

    public function updateUser($con,$id, $name, $lastname, $cellNumber, $email, $password) {
		$password = password_hash($password, PASSWORD_DEFAULT);
        $sql = "UPDATE tbluser SET name ='$name', lastname ='$lastname', cellNumber = '$cellNumber', email = '$email' WHERE id ='$id'";
		$sqlLogin = "UPDATE tbllogin SET password ='$password' WHERE username ='$email'";
		if ($con->query($sql) == TRUE AND $con->query($sqlLogin) == TRUE){
			$_SESSION["name"] = $name;
			$_SESSION["lastname"] = $lastname;
			$_SESSION["email"] = $email;
			$_SESSION["cellNumber"] = $cellNumber;
			return "Personal details successfully updated";
		} else {
			return "Personal details unsuccessfully updated";
		}
    }
	
	public function makeBooking($con, $userId, $doctorId, $appointementDate) {
		$sql= "INSERT INTO tblbooking(userId,doctorId,appointementDate) VALUES('$userId','$doctorId','$appointementDate')";
		if(mysqli_query($con,$sql)) {
			return "Booking Successfully made";
		} else {
			return "Booking unsuccessfully made";
		}
	}
	
	public function getMyPatients($con, $doctorId) {
		$sql = "SELECT b.id, b.appointementDate, b.status, u.name, u.lastname, u.cellNumber from tblbooking b, tblUser u where b.doctorId = '$doctorId' AND b.userId = u.id";
		$check = mysqli_fetch_array(mysqli_query($con,$sql));
		$result = array();
		if(isset($check)){
			$result = $con->query($sql);
		}
		return $result;
	}
	
	public function getMyAppointment($con, $userId) {
		$sql = "SELECT b.appointementDate, b.comment, b.status, d.place, u.name, u.lastname, u.cellNumber from tblbooking b, tbldoctors d, tblUser u where b.userId = '$userId' AND d.userId = b.doctorId AND b.doctorId = u.id";
		$check = mysqli_fetch_array(mysqli_query($con,$sql));
		$result = array();
		if(isset($check)){
			$result = $con->query($sql);
		}
		return $result;
	}
	
	public function getUsersByRole($con, $role) {
        $sql = "SELECT u.id, u.name, u.lastname, u.email, u.cellNumber, l.role, l.status FROM tbllogin l, tbluser u where l.role = '$role' AND u.email = l.username";
		$check = mysqli_fetch_array(mysqli_query($con,$sql));
		$result = array();
		if(isset($check)){
			$result = $con->query($sql);
		}
		return $result;
    }
	
	public function searchDoctor($con, $name,$practiceNumber, $place) {
		$role = 'doctor';
		$status = 'Active';
		$sql = "SELECT u.id, u.name,  d.practiceNumber, d.place, u.lastname, u.email, u.cellNumber, l.role, l.status FROM tbllogin l, tbluser u, tbldoctors d  where l.role = '$role' AND u.email = l.username AND u.id = d.userId AND l.status = '$status'";
		
		if ($name != null){
			$sql = "SELECT u.id, u.name, d.practiceNumber, d.place, u.lastname, u.email, u.cellNumber, l.role, l.status FROM tbllogin l, tbluser u, tbldoctors d where l.role = '$role' AND u.email = l.username AND u.id = d.userId  AND (u.name like '%$name%' OR u.lastname like '%$name%') AND l.status = '$status'";
		} else if ($practiceNumber != null) {
			$sql = "SELECT u.id, u.name, d.practiceNumber, d.place, u.lastname, u.email, u.cellNumber, l.role, l.status FROM tbllogin l, tbluser u, tbldoctors d where l.role = '$role' AND u.email = l.username AND u.id = d.userId AND d.practiceNumber = '$practiceNumber' AND l.status = '$status'";
		} else if ($place != null) {
			$sql = "SELECT u.id, u.name, d.practiceNumber, d.place, u.lastname, u.email, u.cellNumber, l.role, l.status FROM tbllogin l, tbluser u, tbldoctors d where l.role = '$role' AND u.email = l.username AND u.id = d.userId AND d.place like '%$place%' AND l.status = '$status'";
		} else if ($name != null && $practiceNumber != null) {
			$sql = "SELECT u.id, u.name, d.practiceNumber, d.place, u.lastname, u.email, u.cellNumber, l.role, l.status FROM tbllogin l, tbluser u, tbldoctors d where l.role = '$role' AND u.email = l.username AND u.id = d.userId AND (u.name like '%$name%' OR u.lastname like '%$name%') AND d.practiceNumber = '$practiceNumber' AND l.status = '$status'";
		} else if ($name != null && $place != null) {
			$sql = "SELECT u.id, u.name, d.practiceNumber, d.place, u.lastname, u.email, u.cellNumber, l.role, l.status FROM tbllogin l, tbluser u, tbldoctors d where l.role = '$role' AND u.email = l.username AND u.id = d.userId AND (u.name like '%$name%' OR u.lastname like '%$name%') AND d.place like '%$place%' AND l.status = '$status'";
		} else if ($practiceNumber != null && $place != null) {
			$sql = "SELECT u.id, u.name, d.practiceNumber, d.place, u.lastname, u.email, u.cellNumber, l.role, l.status FROM tbllogin l, tbluser u, tbldoctors d where l.role = '$role' AND u.email = l.username AND u.id = d.userId AND d.practiceNumber = '$practiceNumber' AND d.place like '%$place%' AND l.status = '$status'";
		} else if ($name != null && $practiceNumber != null && $place != null) {
			$sql = "SELECT u.id, u.name, d.practiceNumber, d.place, u.lastname, u.email, u.cellNumber, l.role, l.status FROM tbllogin l, tbluser u, tbldoctors d where l.role = '$role' AND u.email = l.username AND u.id = d.userId AND (u.name like '%$name%' OR u.lastname like '%$name%') AND d.place like '%$place%' AND d.practiceNumber = '$practiceNumber' AND l.status = '$status'";
		}
		$check = mysqli_fetch_array(mysqli_query($con,$sql));
		$result = array();
		if(isset($check)){
			$result = $con->query($sql);
		}
		return $result;
	}
	
	public function getDoctorDetails($con, $doctorId) {		
        $result = mysqli_query($con,"SELECT * from tbluser where id = '$doctorId'");
		if($row = mysqli_fetch_array($result)){
			$_SESSION["doctorName"] = $row["name"];
			$_SESSION["doctorLastname"] = $row["lastname"];
		}
	}
	
	public function signin($email, $password, $con) {		
        $result = mysqli_query($con,"SELECT u.id, u.name, u.lastname,u.email, u.cellNumber,l.role, l.password, l.status FROM tbllogin l, tbluser u where l.username = '$email' AND u.email = l.username");
		if($row = mysqli_fetch_array($result)){
			if(password_verify($password, $row["password"])){
				if ($row["status"] === 'Active') {
					$role = $row["role"];
					$_SESSION["role"] = $row["role"];
					$_SESSION["id"] = $row["id"];
					$_SESSION["name"] = $row["name"];
					$_SESSION["lastname"] = $row["lastname"];
					$_SESSION["email"] = $row["email"];
					$_SESSION["cellNumber"] = $row["cellNumber"];
					$_SESSION["password"] = $row["password"];
					
					if($role == 'admin'){	
						return array('status' =>true,'page' => 'admin.php');
					} else if($role == 'doctor'){
						return array('status' =>true,'page' => 'doctor.php');
					} else {
						return array('status' =>true,'page' => 'user.php');
					}
				} else {
					return array('status' =>false,'message' => 'User deactivated');
				}
			} else {
				return array('status' =>false,'message' => 'Wrong password!!!!');
			}
        }else{
			return array('status' =>false,'message' => 'Wrong username!!!!');
		}
	}
}